from app.models.user import User
from app.models.job import Job
from app.models.zodiac import ZodiacSign, Horoscope, UserProfile
from app.models.resume_analysis import ResumeAnalysis
