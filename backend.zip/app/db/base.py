from app.db.base_class import Base
from app.models.user import User
from app.models.job import Job, JobApplication

# Import all models here that should be included in 'create_all'
# This ensures all models are registered with SQLAlchemy
